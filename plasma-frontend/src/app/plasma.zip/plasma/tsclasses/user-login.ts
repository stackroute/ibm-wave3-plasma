export class UserLogin {
    userId: string;
    password: string;
}
