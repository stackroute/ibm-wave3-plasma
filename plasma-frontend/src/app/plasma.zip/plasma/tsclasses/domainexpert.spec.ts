import { Domainexpert } from './domainexpert';

describe('Domainexpert', () => {
  it('should create an instance', () => {
    expect(new Domainexpert()).toBeTruthy();
  });
});
