export interface AppWindow extends Window {
    webkitSpeechRecognition: any;
}
