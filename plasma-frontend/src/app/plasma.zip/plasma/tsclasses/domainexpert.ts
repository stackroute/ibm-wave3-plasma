export class Domainexpert {
    domain: string;
    concept: string[];
}
