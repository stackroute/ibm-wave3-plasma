export class Userregister {
        id: string;
        name: string;
        dateOfBirth: string;
        gender: string;
        contact: string;
        emailId: string;
        setPassword: string;
        confirmpassword: string;

}
