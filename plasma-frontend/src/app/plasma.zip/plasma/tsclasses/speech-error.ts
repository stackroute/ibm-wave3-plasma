export enum SpeechError {
    NO_SPEECH,
    NO_MICROPHONE,
    NOT_ALLOWED,
    BLOCKED
  }
