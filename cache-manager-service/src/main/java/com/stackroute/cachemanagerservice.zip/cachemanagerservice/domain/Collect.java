package com.stackroute.cachemanagerservice.domain;

public class Collect {

    private Intent intent;
    private Relationship relationship;
    private Term term;
}
