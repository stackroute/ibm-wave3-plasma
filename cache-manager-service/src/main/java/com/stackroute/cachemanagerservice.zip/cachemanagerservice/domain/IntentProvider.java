package com.stackroute.cachemanagerservice.domain;

import javax.persistence.Entity;
import java.io.Serializable;

@Entity
public class IntentProvider implements Serializable {

    private static final long serialVersionUID = 7156526077883281623L;

    // @Id
    // @SequenceGenerator(name = "SEQ_GEN", sequenceName = "SEQ_USER", allocationSize = 1)
    // @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN")


}